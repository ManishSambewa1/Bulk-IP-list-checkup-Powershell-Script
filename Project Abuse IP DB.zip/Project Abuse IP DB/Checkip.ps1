# Load Windows Forms assembly
Add-Type -AssemblyName System.Windows.Forms

# Create the form
$form = New-Object System.Windows.Forms.Form
$form.Text = "AbuseIPDB Checker"
$form.Size = New-Object System.Drawing.Size(500, 250)
$form.StartPosition = "CenterScreen"

# Create label for file input
$fileLabel = New-Object System.Windows.Forms.Label
$fileLabel.Text = "Input CSV File:"
$fileLabel.AutoSize = $true
$fileLabel.Location = New-Object System.Drawing.Point(10, 20)
$form.Controls.Add($fileLabel)

# Create text box to display selected file path
$filePathTextBox = New-Object System.Windows.Forms.TextBox
$filePathTextBox.Size = New-Object System.Drawing.Size(300, 20)
$filePathTextBox.Location = New-Object System.Drawing.Point(100, 20)
$form.Controls.Add($filePathTextBox)

# Create Browse button
$browseButton = New-Object System.Windows.Forms.Button
$browseButton.Text = "Browse"
$browseButton.Location = New-Object System.Drawing.Point(410, 18)
$browseButton.Add_Click({
    $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $openFileDialog.Filter = "CSV files (*.csv)|*.csv"
    if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $filePathTextBox.Text = $openFileDialog.FileName
    }
})
$form.Controls.Add($browseButton)

# Create Run button
$runButton = New-Object System.Windows.Forms.Button
$runButton.Text = "Run"
$runButton.Location = New-Object System.Drawing.Point(200, 100)
$runButton.Add_Click({
    # Get the input file path from the text box
    $inputFilePath = $filePathTextBox.Text
    $outputFilePath = [System.IO.Path]::ChangeExtension($inputFilePath, "output.csv")

    if (-not (Test-Path $inputFilePath)) {
        [System.Windows.Forms.MessageBox]::Show("Please select a valid input CSV file.", "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        return
    }

    # Define API Key (replace with your actual key)
    $apiKey = "a34a33c478d1158d810c1eb2dab016d94c3072a42bec6fc6c20419c46a120b0ea3ce725f9b9737c7"

    # Country code-to-name mapping
    $countryMap = $CountryCodeMap = @{
    'AF' = 'Afghanistan'; 'AL' = 'Albania'; 'DZ' = 'Algeria'; 'AS' = 'American Samoa'; 'AD' = 'Andorra'
    'AO' = 'Angola'; 'AG' = 'Antigua and Barbuda'; 'AR' = 'Argentina'; 'AM' = 'Armenia'; 'AU' = 'Australia'
    'AT' = 'Austria'; 'AZ' = 'Azerbaijan'; 'BS' = 'Bahamas'; 'BH' = 'Bahrain'; 'BD' = 'Bangladesh'
    'BB' = 'Barbados'; 'BY' = 'Belarus'; 'BE' = 'Belgium'; 'BZ' = 'Belize'; 'BJ' = 'Benin'
    'BT' = 'Bhutan'; 'BO' = 'Bolivia'; 'BA' = 'Bosnia and Herzegovina'; 'BW' = 'Botswana'; 'BR' = 'Brazil'
    'BN' = 'Brunei'; 'BG' = 'Bulgaria'; 'BF' = 'Burkina Faso'; 'BI' = 'Burundi'; 'KH' = 'Cambodia'
    'CM' = 'Cameroon'; 'CA' = 'Canada'; 'CV' = 'Cape Verde'; 'CF' = 'Central African Republic'
    'TD' = 'Chad'; 'CL' = 'Chile'; 'CN' = 'China'; 'CO' = 'Colombia'; 'KM' = 'Comoros'; 'CG' = 'Congo'
    'CR' = 'Costa Rica'; 'HR' = 'Croatia'; 'CU' = 'Cuba'; 'CY' = 'Cyprus'; 'CZ' = 'Czech Republic'
    'DK' = 'Denmark'; 'DJ' = 'Djibouti'; 'DM' = 'Dominica'; 'DO' = 'Dominican Republic'; 'EC' = 'Ecuador'
    'EG' = 'Egypt'; 'SV' = 'El Salvador'; 'GQ' = 'Equatorial Guinea'; 'ER' = 'Eritrea'; 'EE' = 'Estonia'
    'ET' = 'Ethiopia'; 'FJ' = 'Fiji'; 'FI' = 'Finland'; 'FR' = 'France'; 'GA' = 'Gabon'; 'GM' = 'Gambia'
    'GE' = 'Georgia'; 'DE' = 'Germany'; 'GH' = 'Ghana'; 'GR' = 'Greece'; 'GD' = 'Grenada'; 'GT' = 'Guatemala'
    'GN' = 'Guinea'; 'GW' = 'Guinea-Bissau'; 'GY' = 'Guyana'; 'HT' = 'Haiti'; 'HN' = 'Honduras'; 'HU' = 'Hungary'; 'HK' = 'Hong Kong';
    'IS' = 'Iceland'; 'IN' = 'India'; 'ID' = 'Indonesia'; 'IR' = 'Iran'; 'IQ' = 'Iraq'; 'IE' = 'Ireland'
    'IL' = 'Israel'; 'IT' = 'Italy'; 'JM' = 'Jamaica'; 'JP' = 'Japan'; 'JO' = 'Jordan'; 'KZ' = 'Kazakhstan'
    'KE' = 'Kenya'; 'KI' = 'Kiribati'; 'KP' = 'North Korea'; 'KR' = 'South Korea'; 'KW' = 'Kuwait'
    'KG' = 'Kyrgyzstan'; 'LA' = 'Laos'; 'LV' = 'Latvia'; 'LB' = 'Lebanon'; 'LS' = 'Lesotho'; 'LR' = 'Liberia'
    'LY' = 'Libya'; 'LI' = 'Liechtenstein'; 'LT' = 'Lithuania'; 'LU' = 'Luxembourg'; 'MG' = 'Madagascar'
    'MW' = 'Malawi'; 'MY' = 'Malaysia'; 'MV' = 'Maldives'; 'ML' = 'Mali'; 'MT' = 'Malta'; 'MH' = 'Marshall Islands'
    'MR' = 'Mauritania'; 'MU' = 'Mauritius'; 'MX' = 'Mexico'; 'FM' = 'Micronesia'; 'MD' = 'Moldova'
    'MC' = 'Monaco'; 'MN' = 'Mongolia'; 'ME' = 'Montenegro'; 'MA' = 'Morocco'; 'MZ' = 'Mozambique'
    'MM' = 'Myanmar'; 'NA' = 'Namibia'; 'NR' = 'Nauru'; 'NP' = 'Nepal'; 'NL' = 'Netherlands'; 'NZ' = 'New Zealand'
    'NI' = 'Nicaragua'; 'NE' = 'Niger'; 'NG' = 'Nigeria'; 'NO' = 'Norway'; 'OM' = 'Oman'; 'PK' = 'Pakistan'
    'PW' = 'Palau'; 'PA' = 'Panama'; 'PG' = 'Papua New Guinea'; 'PY' = 'Paraguay'; 'PE' = 'Peru'
    'PH' = 'Philippines'; 'PL' = 'Poland'; 'PT' = 'Portugal'; 'QA' = 'Qatar'; 'RO' = 'Romania'; 'RU' = 'Russia'
    'RW' = 'Rwanda'; 'WS' = 'Samoa'; 'SM' = 'San Marino'; 'SA' = 'Saudi Arabia'; 'SN' = 'Senegal'
    'RS' = 'Serbia'; 'SC' = 'Seychelles'; 'SL' = 'Sierra Leone'; 'SG' = 'Singapore'; 'SK' = 'Slovakia'
    'SI' = 'Slovenia'; 'SB' = 'Solomon Islands'; 'SO' = 'Somalia'; 'ZA' = 'South Africa'; 'ES' = 'Spain'
    'LK' = 'Sri Lanka'; 'SD' = 'Sudan'; 'SR' = 'Suriname'; 'SZ' = 'Swaziland'; 'SE' = 'Sweden'
    'CH' = 'Switzerland'; 'SY' = 'Syria'; 'TW' = 'Taiwan'; 'TJ' = 'Tajikistan'; 'TZ' = 'Tanzania'
    'TH' = 'Thailand'; 'TL' = 'Timor-Leste'; 'TG' = 'Togo'; 'TO' = 'Tonga'; 'TT' = 'Trinidad and Tobago'
    'TN' = 'Tunisia'; 'TR' = 'Turkey'; 'TM' = 'Turkmenistan'; 'UG' = 'Uganda'; 'UA' = 'Ukraine'
    'AE' = 'United Arab Emirates'; 'GB' = 'United Kingdom'; 'US' = 'United States'; 'UY' = 'Uruguay'
    'UZ' = 'Uzbekistan'; 'VU' = 'Vanuatu'; 'VA' = 'Vatican City'; 'VE' = 'Venezuela'; 'VN' = 'Vietnam'
    'YE' = 'Yemen'; 'ZM' = 'Zambia'; 'ZW' = 'Zimbabwe'
    # Additional territories and regions
    'MO' = 'Macau'; 'PR' = 'Puerto Rico'; 'GL' = 'Greenland'; 'BM' = 'Bermuda'; 'GI' = 'Gibraltar'
    'GU' = 'Guam'; 'VI' = 'United States Virgin Islands'; 'MP' = 'Northern Mariana Islands'
}

    # Read the input CSV
    $ipList = Import-Csv -Path $inputFilePath
    $output = @()

    $counter = 0
    $totalIPs = $ipList.Count

    # Create a label to display the current IP being processed
    $statusLabel = New-Object System.Windows.Forms.Label
    $statusLabel.Text = "Processing IP 0 of $totalIPs"
    $statusLabel.AutoSize = $true
    $statusLabel.Location = New-Object System.Drawing.Point(50, 150)
    $form.Controls.Add($statusLabel)

    foreach ($ip in $ipList) {
        $ipAddress = $ip.IPAddress
        try {
            $response = Invoke-RestMethod -Uri "https://api.abuseipdb.com/api/v2/check?ipAddress=$ipAddress&maxAgeInDays=90" `
                                          -Headers @{ "Key" = $apiKey } `
                                          -Method Get

            $countryCode = $response.data.countryCode
            $countryName = $countryMap[$countryCode]
            if (-not $countryName) { $countryName = "Unknown" }

            $outputObject = [PSCustomObject]@{
                "Source IP" = $ipAddress
                "Country" = $countryName
                "Abuse Percentage" = "$($response.data.abuseConfidenceScore)%"
                "Reported Times" = "$($response.data.totalReports) times"
                "ISP" = $response.data.isp
                "Domain" = $response.data.domain
                "Abuse Categories" = ($response.data.categories -join ", ")
            }

            $output += $outputObject
        }
        catch {
            Write-Host "Error processing IP: $ipAddress"
            Write-Host $_.Exception.Message
            $output += [PSCustomObject]@{
                "Source IP" = $ipAddress
                "Country" = "Error"
                "Abuse Percentage" = "Error"
                "Reported Times" = "Error"
                "ISP" = "Error"
                "Domain" = "Error"
                "Abuse Categories" = "Error"
            }
        }

        # Update the status label with the current IP being processed
        $counter++
        $statusLabel.Text = "Processing IP $counter of $totalIPs"
        $form.Refresh()  # Refresh the form to update the label

    }

    # Export results to CSV
    $output | Export-Csv -Path $outputFilePath -NoTypeInformation -Force

    # Notify user of completion
    [System.Windows.Forms.MessageBox]::Show("Report generated successfully at $outputFilePath", "Success", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
})
$form.Controls.Add($runButton)

# Show the form
$form.ShowDialog()
